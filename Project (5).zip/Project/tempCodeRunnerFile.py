# app.py — Integrated UNSW + CICIDS Flask app (final)
# ============================================================
# ============================================================
# App setup
# ============================================================
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file
)
from markupsafe import Markup

from werkzeug.security import check_password_hash, generate_password_hash

import os, io, csv, uuid, traceback, pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")   # IMPORTANT: non-interactive backend for server
import matplotlib.pyplot as plt
import shap
from lime.lime_tabular import LimeTabularExplainer

# ============================================================
# App setup
# ============================================================
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = "CHANGE_THIS_TO_A_SECURE_RANDOM_KEY"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Ensure necessary folders exist
os.makedirs(os.path.join(BASE_DIR, "static", "outputs"), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "static", "plots"), exist_ok=True)

# ============================================================
# Paths — UNSW and CICIDS artifact locations
# ============================================================
UNSW_DIR = os.path.join(BASE_DIR, "model")               # UNSW artifacts
UNSW_MODEL_PATH   = os.path.join(UNSW_DIR, "xgb_model.pkl")
UNSW_SCALER_PATH  = os.path.join(UNSW_DIR, "scaler.pkl")
UNSW_ENCODER_PATH = os.path.join(UNSW_DIR, "encoders.pkl")
UNSW_FEAT_PATH    = os.path.join(UNSW_DIR, "feature_list.pkl")
UNSW_TARGET_PATH  = os.path.join(UNSW_DIR, "target_encoder.pkl")  # optional

CICIDS_DIR = os.path.join(BASE_DIR, "model_cicids")      # CICIDS artifacts
CIC_MODEL_PATH   = os.path.join(CICIDS_DIR, "xgb_model.pkl")
CIC_SCALER_PATH  = os.path.join(CICIDS_DIR, "scaler.pkl")
CIC_ENCODER_PATH = os.path.join(CICIDS_DIR, "encoders.pkl")
CIC_FEAT_PATH    = os.path.join(CICIDS_DIR, "feature_list.pkl")
CIC_TARGET_PATH  = os.path.join(CICIDS_DIR, "target_encoder.pkl")
CIC_LIME_BG_PATH = os.path.join(CICIDS_DIR, "lime_background.pkl")

# ============================================================
# Load UNSW artifacts (if present)
# ============================================================
try:
    UNSW_MODEL   = pickle.load(open(UNSW_MODEL_PATH, "rb"))
    UNSW_SCALER  = pickle.load(open(UNSW_SCALER_PATH, "rb"))
    UNSW_ENCODERS= pickle.load(open(UNSW_ENCODER_PATH, "rb"))
    UNSW_FEAT    = list(pickle.load(open(UNSW_FEAT_PATH, "rb")))
    # normalize UNSW_feat to lower-case (you trained with lowercase)
    UNSW_FEAT = [f.lower() for f in UNSW_FEAT]
    UNSW_CATEGORICALS = [c for c in UNSW_FEAT if c in UNSW_ENCODERS]
    UNSW_NUMERICS = [c for c in UNSW_FEAT if c not in UNSW_ENCODERS]
    UNSW_EXPLAINER = shap.TreeExplainer(UNSW_MODEL)
    print("Loaded UNSW artifacts.")
except Exception as e:
    print("Warning loading UNSW artifacts:", e)
    UNSW_MODEL = UNSW_SCALER = UNSW_ENCODERS = UNSW_FEAT = None
    UNSW_CATEGORICALS = UNSW_NUMERICS = []
    UNSW_EXPLAINER = None

# ============================================================
# Load CICIDS artifacts (if present)
# IMPORTANT — keep CICIDS feature names AS-IS (case-sensitive)
# ============================================================
try:
    CIC_MODEL   = pickle.load(open(CIC_MODEL_PATH, "rb"))
    CIC_SCALER  = pickle.load(open(CIC_SCALER_PATH, "rb"))
    CIC_ENCODERS_RAW = pickle.load(open(CIC_ENCODER_PATH, "rb"))   # mappings saved during training
    CIC_FEAT_RAW = list(pickle.load(open(CIC_FEAT_PATH, "rb")))   # keep original case
    CIC_TARGET_MAP = pickle.load(open(CIC_TARGET_PATH, "rb"))
    CIC_LIME_BG  = pickle.load(open(CIC_LIME_BG_PATH, "rb"))
    # do NOT lowercase CIC_FEAT_RAW — keep exact names
    CIC_FEAT = CIC_FEAT_RAW.copy()
    # Build encoders keyed by exact original column names (case-sensitive)
    # If encoders file uses original case keys, keep as-is; else try lowercased fallback mapping
    CIC_ENCODERS = {}
    if isinstance(CIC_ENCODERS_RAW, dict):
        # the training code may have saved mapping dicts; handle both styles
        for k, v in CIC_ENCODERS_RAW.items():
            CIC_ENCODERS[k] = v
    CIC_CATEGORICALS = [c for c in CIC_FEAT if c in CIC_ENCODERS]
    CIC_NUMERICS = [c for c in CIC_FEAT if c not in CIC_ENCODERS]
    CIC_EXPLAINER = shap.TreeExplainer(CIC_MODEL)
    print("Loaded CICIDS artifacts.")
except Exception as e:
    print("Warning loading CICIDS artifacts:", e)
    CIC_MODEL = CIC_SCALER = CIC_ENCODERS = CIC_FEAT = CIC_TARGET_MAP = CIC_LIME_BG = None
    CIC_CATEGORICALS = CIC_NUMERICS = []
    CIC_EXPLAINER = None

# ============================================================
# Authentication
# ============================================================
USERNAME = "admin"
PASSWORD_HASH = generate_password_hash("admin123")

# ============================================================
# Utility: robust upload parser (CSV/Excel/whitespace)
# ============================================================
def safe_parse_upload(file_bytes):
    df = None
    errors = []
    try:
        sample = file_bytes[:8192].decode(errors="ignore")
        sn = csv.Sniffer()
        try:
            dialect = sn.sniff(sample)
            df = pd.read_csv(io.BytesIO(file_bytes), sep=dialect.delimiter, engine="python")
        except Exception:
            df = pd.read_csv(io.BytesIO(file_bytes), engine="python")
    except Exception as e:
        errors.append(f"csv fail: {e}")
        df = None

    if df is None:
        try:
            df = pd.read_excel(io.BytesIO(file_bytes))
        except Exception as e:
            errors.append(f"excel fail: {e}")
            df = None

    if df is None:
        try:
            df = pd.read_csv(io.BytesIO(file_bytes), sep=r"\s+", engine="python")
        except Exception as e:
            errors.append(f"whitespace fail: {e}")
            df = None

    if df is None:
        return None, "Failed to parse file. " + " | ".join(errors)

    # keep original column names but strip spaces; also create lowercase mapping when needed
    df.columns = df.columns.str.strip()
    return df, None

# ============================================================
# UNSW helpers (trained with lowercase features)
# ============================================================
def _unsw_safe_label_transform(series, le):
    """label encoder object -> transform with unseen -> len(classes)"""
    classes = list(le.classes_)
    mapping = {c:i for i,c in enumerate(classes)}
    unk = len(classes)
    return np.array([mapping.get(str(v), unk) for v in series.astype(str)], dtype=int)

def unsw_prepare(df_raw):
    if UNSW_MODEL is None:
        raise RuntimeError("UNSW model not loaded.")
    df = df_raw.copy()
    # Lowercase column names for UNSW (the model expects lowercase colnames)
    df.columns = df.columns.str.lower().str.strip()
    # add missing UNSW features as zeros
    for c in UNSW_FEAT:
        if c not in df.columns:
            df[c] = 0
    df = df[UNSW_FEAT].copy()
    # encode categoricals
    for c in UNSW_CATEGORICALS:
        df[c] = _unsw_safe_label_transform(df[c], UNSW_ENCODERS[c])
    # numeric cast
    for c in UNSW_NUMERICS:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
    X = df.astype(float)
    # If the scaler was fitted with feature_names_in_, ensure same order
    try:
        fnames = getattr(UNSW_SCALER, "feature_names_in_", None)
        if fnames is not None:
            # scaler expects feature names possibly with original case — but for UNSW we used lowercase
            # Ensure order matches scaler
            X = X[ list(fnames) ].astype(float)
    except Exception:
        pass
    Xs = UNSW_SCALER.transform(X)
    return Xs, df

# ============================================================
# CICIDS helpers (case-sensitive — DO NOT lowercase features)
# - We will try to map uploaded column names to the model's feature names:
#   if user uploaded lowercase names, attempt to match by lowercasing keys.
# ============================================================
def _cic_safe_label_transform(series, mapping):
    unk = len(mapping)
    return np.array([mapping.get(str(v), unk) for v in series.astype(str)], dtype=int)

def cic_prepare(df_raw):
    if CIC_MODEL is None:
        raise RuntimeError("CICIDS model not loaded.")
    df = df_raw.copy()
    # Keep original column casing — but users may upload lowercase names.
    # Build a mapping from lowercase-uploaded to model feature names if necessary.
    upload_cols = list(df.columns)
    # Make an easy mapping: lowercase(upload_col) -> actual upload_col
    upload_lower_map = {c.lower(): c for c in upload_cols}

    # If uploaded columns are lowercase but model expects 'Flow Duration', we try to rename accordingly:
    # Build rename dict: if model_feat.lower() exists in upload_lower_map, map upload col -> model_feat
    rename_map = {}
    for model_feat in CIC_FEAT:
        if model_feat in df.columns:
            # exact name present — keep as is
            continue
        key = model_feat.lower()
        if key in upload_lower_map:
            rename_map[ upload_lower_map[key] ] = model_feat

    if rename_map:
        df = df.rename(columns=rename_map)

    # Now ensure every CIC_FEAT exists; if missing, add zeros (we're following your choice B)
    for c in CIC_FEAT:
        if c not in df.columns:
            df[c] = 0

    # Reorder columns exactly as CIC_FEAT (case-sensitive order)
    df = df[CIC_FEAT].copy()

    # Encode categorical columns using saved mapping dicts
    for c in CIC_CATEGORICALS:
        mapping = CIC_ENCODERS.get(c, {})
        df[c] = _cic_safe_label_transform(df[c], mapping)

    # Numeric casting
    for c in CIC_NUMERICS:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    X = df.astype(float)

    # Align to scaler.feature_names_in_ if present (scaler likely fit with original feature names)
    try:
        fnames = getattr(CIC_SCALER, "feature_names_in_", None)
        if fnames is not None:
            # if fnames are exactly the same as CIC_FEAT ordering, ok.
            # otherwise reindex X to match scaler's expected columns (scaler likely uses original case)
            missing = [f for f in fnames if f not in X.columns]
            extra = [f for f in X.columns if f not in fnames]
            # add missing columns with zeros
            for m in missing:
                X[m] = 0.0
            # drop extra columns
            if extra:
                X = X.drop(columns=extra)
            # reorder
            X = X[list(fnames)].astype(float)
    except Exception:
        pass

    Xs = CIC_SCALER.transform(X)
    return Xs, df

# ============================================================
# Visualization: SHAP + LIME plotting helpers (nice-looking bars)
# ============================================================
def save_shap_plot_shallow(explainer, Xs, feature_names, idx, save_path, topk=10, title="SHAP"):
    """SHAP plotting with full multiclass support."""
    try:
        sv = explainer.shap_values(Xs)

        # ---- HANDLE MULTICLASS SHAP ----
        if isinstance(sv, list):
            # SHAP returns list[class] → choose predicted class
            pred_class = np.argmax(explainer.model.predict_proba(Xs)[idx])
            row = sv[pred_class][idx]   # shape: (features,)
        else:
            # Binary/Regression → normal
            row = sv[idx]

        # Convert to flat numpy vector
        row = np.array(row).flatten()

        # Sort by absolute importance
        feat = np.array(feature_names)
        srt = np.argsort(np.abs(row))[::-1][:topk]
        f = feat[srt]
        v = row[srt]

        colors = ["#27ae60" if x > 0 else "#c0392b" for x in v]

        plt.figure(figsize=(10, 5))
        bars = plt.barh(f[::-1], v[::-1], color=colors[::-1])

        for bar, val in zip(bars, v[::-1]):
            plt.text(
                bar.get_width(),
                bar.get_y() + bar.get_height()/2,
                f"{val:.5f}",
                va="center", fontsize=9
            )

        plt.title(title, fontsize=13, weight="bold")
        plt.xlabel("SHAP value")
        plt.grid(axis="x", linestyle="--", alpha=0.3)
        plt.tight_layout()
        plt.savefig(save_path, dpi=120)
        plt.close()

        return True, None

    except Exception as e:
        return False, traceback.format_exc()


def save_lime_plot(Xs, model, feature_names, background, idx, save_path, topk=10, title="LIME - Top Features"):
    try:
        bg = background if (background is not None and getattr(background, "shape", None) is not None and background.shape[0]>=1) else np.zeros((1, Xs.shape[1]))
        lime_expl = LimeTabularExplainer(training_data=bg,
                                         feature_names=feature_names,
                                         mode="classification")
        exp = lime_expl.explain_instance(Xs[idx], model.predict_proba, num_features=topk)
        feats, vals = zip(*exp.as_list())
        feats = np.array(feats); vals = np.array(vals)
        srt = np.argsort(np.abs(vals))[::-1]
        feats, vals = feats[srt], vals[srt]
        colors = ["#2ecc71" if v>0 else "#e74c3c" for v in vals]
        plt.figure(figsize=(10,5))
        bars = plt.barh(feats[::-1], vals[::-1], color=colors[::-1])
        for bar, val in zip(bars, vals[::-1]):
            plt.text(bar.get_width(), bar.get_y() + bar.get_height()/2, f"{val:.5f}", va="center", fontsize=9)
        plt.title(title, fontsize=13, weight="bold")
        plt.xlabel("LIME weight")
        plt.grid(axis="x", linestyle="--", alpha=0.3)
        plt.tight_layout()
        plt.savefig(save_path, dpi=120)
        plt.close()
        return True, None
    except Exception:
        return False, traceback.format_exc()

# ============================================================
# Routes: index, auth
# ============================================================
@app.route("/")
def index():
    return render_template("welcome.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        uname = request.form.get("username")
        pwd = request.form.get("password")
        if uname == USERNAME and check_password_hash(PASSWORD_HASH, pwd):
            session["user"] = uname
            return redirect(url_for("predict"))
        return render_template("login.html", error="Invalid username or password")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ============================================================
# UNSW: single predict + upload/batch
# ============================================================
@app.route("/predict", methods=["GET","POST"])
def predict():
    if "user" not in session:
        return redirect(url_for("login"))
    # GET -> show form
    if request.method == "GET":
        feat_vals = {}
        for c in (UNSW_CATEGORICALS or []):
            le = UNSW_ENCODERS.get(c)
            if le is not None and hasattr(le, "classes_"):
                feat_vals[c] = le.classes_.tolist()
        return render_template("predict.html",
                               feature_list=UNSW_FEAT,
                               categorical_features=UNSW_CATEGORICALS,
                               numeric_features=UNSW_NUMERICS,
                               feature_values=feat_vals)
    # POST -> predict
    data = {c: request.form.get(c) for c in UNSW_FEAT}
    df = pd.DataFrame([data])
    try:
        Xs, df_ordered = unsw_prepare(df)
    except Exception as e:
        flash(f"Prepare error: {e}", "danger")
        return redirect(url_for("predict"))
    pred = UNSW_MODEL.predict(Xs)[0]
    # decode target if available
    if os.path.exists(UNSW_TARGET_PATH):
        try:
            le_target = pickle.load(open(UNSW_TARGET_PATH, "rb"))
            if hasattr(le_target, "inverse_transform"):
                pred_label = le_target.inverse_transform([pred])[0]
            elif isinstance(le_target, dict):
                inv = {v:k for k,v in le_target.items()}
                pred_label = inv.get(pred, str(pred))
            else:
                pred_label = str(pred)
        except Exception:
            pred_label = str(pred)
    else:
        pred_label = "Normal" if pred == 0 else "Attack"
    # make plots for single row
    uid = str(uuid.uuid4())
    plot_dir = os.path.join(BASE_DIR, "static", "plots", uid)
    os.makedirs(plot_dir, exist_ok=True)
    shap_path = os.path.join(plot_dir, "shap_single.png")
    lime_path = os.path.join(plot_dir, "lime_single.png")
    ok_s, s_err = save_shap_plot_shallow(UNSW_EXPLAINER, Xs, UNSW_FEAT, 0, shap_path, title="SHAP - UNSW Top Features")
    ok_l, l_err = save_lime_plot(Xs, UNSW_MODEL, UNSW_FEAT, None, 0, lime_path, title="LIME - UNSW Top Features")
    return render_template("result.html",
                           prediction=pred_label,
                           shap_img=f"plots/{uid}/shap_single.png",
                           lime_img=f"plots/{uid}/lime_single.png",
                           single_row=df_ordered.iloc[0].to_dict(),
                           severity_color="#2ecc71" if str(pred_label).lower() in ["normal","benign"] else "#dc3545")

@app.route("/upload_preview", methods=["POST"])
def upload_preview():
    if "user" not in session:
        return redirect(url_for("login"))
    file = request.files.get("csvfile")
    if not file:
        flash("No file uploaded", "danger")
        return redirect(url_for("predict"))
    df, err = safe_parse_upload(file.read())
    if df is None:
        flash(err, "danger")
        return redirect(url_for("predict"))
    uid = str(uuid.uuid4()); tmp = f"{uid}.csv"
    df.to_csv(os.path.join(BASE_DIR, "static", "outputs", tmp), index=False)
    preview_html = df.head(20).to_html(classes="table table-striped", index=False)
    return render_template("preview.html", preview_table=Markup(preview_html), tmp_csv=tmp)

@app.route("/confirm_predict", methods=["POST"])
def confirm_predict():
    if "user" not in session:
        return redirect(url_for("login"))
    tmp = request.form.get("tmp_csv")
    path = os.path.join(BASE_DIR, "static", "outputs", tmp)
    if not os.path.exists(path):
        flash("Temp file not found", "danger")
        return redirect(url_for("predict"))
    df = pd.read_csv(path)
    try:
        Xs, df_proc = unsw_prepare(df)
    except Exception as e:
        flash(f"Prepare error: {e}", "danger")
        return redirect(url_for("predict"))
    preds = UNSW_MODEL.predict(Xs)
    # decode
    if os.path.exists(UNSW_TARGET_PATH):
        try:
            le_target = pickle.load(open(UNSW_TARGET_PATH, "rb"))
            if hasattr(le_target, "inverse_transform"):
                pred_labels = le_target.inverse_transform(preds)
            elif isinstance(le_target, dict):
                inv = {v:k for k,v in le_target.items()}
                pred_labels = [inv.get(p, str(p)) for p in preds]
            else:
                pred_labels = [str(p) for p in preds]
        except Exception:
            pred_labels = [str(p) for p in preds]
    else:
        pred_labels = ["Normal" if p==0 else "Attack" for p in preds]
    # save output csv
    uid = str(uuid.uuid4()); out_name = f"results_{uid}.csv"; out_path = os.path.join(BASE_DIR, "static", "outputs", out_name)
    df_out = df.copy(); df_out["prediction"] = pred_labels; df_out.to_csv(out_path, index=False)
    # generate plots for first up to 50 rows
    plot_uid = uid; plot_dir = os.path.join(BASE_DIR, "static", "plots", plot_uid); os.makedirs(plot_dir, exist_ok=True)
    items = []
    max_rows = min(50, len(df_proc))
    for i in range(max_rows):
        shap_fn = f"shap_row_{i}.png"; lime_fn = f"lime_row_{i}.png"
        shap_p = os.path.join(plot_dir, shap_fn); lime_p = os.path.join(plot_dir, lime_fn)
        ok_s, s_err = save_shap_plot_shallow(UNSW_EXPLAINER, Xs, UNSW_FEAT, i, shap_p, title="SHAP - UNSW Top Features")
        ok_l, l_err = save_lime_plot(Xs, UNSW_MODEL, UNSW_FEAT, None, i, lime_p, title="LIME - UNSW Top Features")
        items.append({
            "row": i,
            "prediction": pred_labels[i],
            "shap_img": f"plots/{plot_uid}/{shap_fn}",
            "lime_img": f"plots/{plot_uid}/{lime_fn}",
            "shap_ok": ok_s,
            "lime_ok": ok_l,
            "shap_err": s_err,
            "lime_err": l_err
        })
    return render_template("batch_visualization.html", items=items, download_file=out_name)

# ============================================================
# CICIDS: predict + upload/batch (case-sensitive features preserved)
# ============================================================
@app.route("/predict_cicids", methods=["GET","POST"])
def predict_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    if request.method == "GET":
        feat_vals = {}
        for c in (CIC_CATEGORICALS or []):
            mapping = CIC_ENCODERS.get(c, {})
            feat_vals[c] = sorted(list(mapping.keys()))
        return render_template("predict_cicids.html",
                               feature_list=CIC_FEAT,
                               categorical_features=CIC_CATEGORICALS,
                               numeric_features=CIC_NUMERICS,
                               feature_values=feat_vals)
    data = {c: request.form.get(c) for c in CIC_FEAT}
    df = pd.DataFrame([data])
    try:
        Xs, df_proc = cic_prepare(df)
    except Exception as e:
        flash(f"CIC prepare error: {e}", "danger")
        return redirect(url_for("predict_cicids"))
    pred_idx = CIC_MODEL.predict(Xs)[0]
    # inverse map target
    inv = {v:k for k,v in CIC_TARGET_MAP.items()} if isinstance(CIC_TARGET_MAP, dict) else None
    pred_label = inv.get(pred_idx, str(pred_idx)) if inv is not None else str(pred_idx)
    uid = str(uuid.uuid4()); plot_dir = os.path.join(BASE_DIR, "static", "plots", f"cic_{uid}"); os.makedirs(plot_dir, exist_ok=True)
    shap_p = os.path.join(plot_dir, "shap_single.png"); lime_p = os.path.join(plot_dir, "lime_single.png")
    ok_s, s_err = save_shap_plot_shallow(CIC_EXPLAINER, Xs, CIC_FEAT, 0, shap_p, title="SHAP - CICIDS Top Features")
    ok_l, l_err = save_lime_plot(Xs, CIC_MODEL, CIC_FEAT, CIC_LIME_BG, 0, lime_p, title="LIME - CICIDS Top Features")
    return render_template("result_cicids.html",
                           prediction=pred_label,
                           shap_img=f"plots/cic_{uid}/shap_single.png",
                           lime_img=f"plots/cic_{uid}/lime_single.png",
                           single_row=df_proc.iloc[0].to_dict(),
                           severity_color="#2ecc71" if "benign" in pred_label.lower() else "#dc3545")

@app.route("/upload_preview_cicids", methods=["POST"])
def upload_preview_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    file = request.files.get("csvfile")
    if not file:
        flash("No file uploaded", "danger")
        return redirect(url_for("predict_cicids"))
    df, err = safe_parse_upload(file.read())
    if df is None:
        flash(err, "danger")
        return redirect(url_for("predict_cicids"))
    uid = str(uuid.uuid4()); tmp = f"cic_{uid}.csv"; df.to_csv(os.path.join(BASE_DIR, "static", "outputs", tmp), index=False)
    preview_html = df.head(20).to_html(classes="table table-striped", index=False)
    # pass cicids_mode flag to preview template so confirm button posts to /confirm_predict_cicids
    return render_template("preview.html", preview_table=Markup(preview_html), tmp_csv=tmp, cicids_mode=True)

@app.route("/confirm_predict_cicids", methods=["POST"])
def confirm_predict_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    tmp = request.form.get("tmp_csv")
    path = os.path.join(BASE_DIR, "static", "outputs", tmp)
    if not os.path.exists(path):
        flash("Temp file not found", "danger")
        return redirect(url_for("predict_cicids"))
    df = pd.read_csv(path)
    try:
        Xs, df_proc = cic_prepare(df)
    except Exception as e:
        flash(f"CIC prepare error: {e}", "danger")
        return redirect(url_for("predict_cicids"))
    preds_idx = CIC_MODEL.predict(Xs)
    inv = {v:k for k,v in CIC_TARGET_MAP.items()} if isinstance(CIC_TARGET_MAP, dict) else None
    pred_labels = [inv.get(int(p), str(p)) for p in preds_idx] if inv is not None else [str(p) for p in preds_idx]
    uid = str(uuid.uuid4()); out_name = f"cic_results_{uid}.csv"; out_path = os.path.join(BASE_DIR, "static", "outputs", out_name)
    df_out = df.copy(); df_out["prediction"] = pred_labels; df_out.to_csv(out_path, index=False)
    plot_uid = f"cic_{uid}"; plot_dir = os.path.join(BASE_DIR, "static", "plots", plot_uid); os.makedirs(plot_dir, exist_ok=True)
    items = []
    max_rows = min(50, len(df_proc))
    for i in range(max_rows):
        shap_fn = f"shap_{i}.png"; lime_fn = f"lime_{i}.png"
        shap_p = os.path.join(plot_dir, shap_fn); lime_p = os.path.join(plot_dir, lime_fn)
        ok_s, s_err = save_shap_plot_shallow(CIC_EXPLAINER, Xs, CIC_FEAT, i, shap_p, title="SHAP - CICIDS Top Features")
        ok_l, l_err = save_lime_plot(Xs, CIC_MODEL, CIC_FEAT, CIC_LIME_BG, i, lime_p, title="LIME - CICIDS Top Features")
        items.append({
            "row": i,
            "prediction": pred_labels[i],
            "shap_img": f"plots/{plot_uid}/{shap_fn}",
            "lime_img": f"plots/{plot_uid}/{lime_fn}",
            "shap_ok": ok_s,
            "lime_ok": ok_l,
            "shap_err": s_err,
            "lime_err": l_err
        })
    return render_template("batch_visualization_cicids.html", items=items, download_file=out_name)

# ============================================================
# Download route
# ============================================================
@app.route("/download/<path:filename>")
def download_file_route(filename):
    if "user" not in session:
        return redirect(url_for("login"))
    path = os.path.join(BASE_DIR, "static", "outputs", filename)
    if not os.path.exists(path):
        flash("File not found", "danger")
        return redirect(url_for("predict"))
    return send_file(path, as_attachment=True)

# ============================================================
# Run
# ============================================================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
