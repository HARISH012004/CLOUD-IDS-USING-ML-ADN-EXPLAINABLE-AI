# app.py — Integrated UNSW + CICIDS Flask app (final)
# Single-file, production-ready (local dev mode)
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file
)
from markupsafe import Markup
from werkzeug.security import check_password_hash, generate_password_hash

import os, io, csv, uuid, traceback, pickle, math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")   # non-interactive backend for server
import matplotlib.pyplot as plt
import shap
from lime.lime_tabular import LimeTabularExplainer

# ---------------- app setup ----------------
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = "CHANGE_THIS_TO_A_SECURE_RANDOM_KEY"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

os.makedirs(os.path.join(BASE_DIR, "static", "outputs"), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "static", "plots"), exist_ok=True)

# ---------------- artifact paths ----------------
UNSW_DIR = os.path.join(BASE_DIR, "model")
UNSW_MODEL_PATH   = os.path.join(UNSW_DIR, "xgb_model.pkl")
UNSW_SCALER_PATH  = os.path.join(UNSW_DIR, "scaler.pkl")
UNSW_ENCODER_PATH = os.path.join(UNSW_DIR, "encoders.pkl")
UNSW_FEAT_PATH    = os.path.join(UNSW_DIR, "feature_list.pkl")
UNSW_TARGET_PATH  = os.path.join(UNSW_DIR, "target_encoder.pkl")
UNSW_LIME_BG_PATH = os.path.join(UNSW_DIR, "lime_background_unsw.pkl")  # new

CICIDS_DIR = os.path.join(BASE_DIR, "model_cicids")
CIC_MODEL_PATH   = os.path.join(CICIDS_DIR, "xgb_model.pkl")
CIC_SCALER_PATH  = os.path.join(CICIDS_DIR, "scaler.pkl")
CIC_ENCODER_PATH = os.path.join(CICIDS_DIR, "encoders.pkl")
CIC_FEAT_PATH    = os.path.join(CICIDS_DIR, "feature_list.pkl")
CIC_TARGET_PATH  = os.path.join(CICIDS_DIR, "target_encoder.pkl")
CIC_LIME_BG_PATH = os.path.join(CICIDS_DIR, "lime_background.pkl")

# ---------------- load UNSW artifacts ----------------
try:
    UNSW_MODEL   = pickle.load(open(UNSW_MODEL_PATH, "rb"))
    UNSW_SCALER  = pickle.load(open(UNSW_SCALER_PATH, "rb"))
    UNSW_ENCODERS= pickle.load(open(UNSW_ENCODER_PATH, "rb"))
    UNSW_FEAT    = list(pickle.load(open(UNSW_FEAT_PATH, "rb")))
    # the training pipeline used lowercase feature names for UNSW; keep consistent
    UNSW_FEAT = [f.lower() for f in UNSW_FEAT]
    UNSW_CATEGORICALS = [c for c in UNSW_FEAT if c in UNSW_ENCODERS]
    UNSW_NUMERICS = [c for c in UNSW_FEAT if c not in UNSW_ENCODERS]
    UNSW_EXPLAINER = shap.TreeExplainer(UNSW_MODEL)
    # try load UNSW LIME background if saved during training (recommended)
    try:
        UNSW_LIME_BG = pickle.load(open(UNSW_LIME_BG_PATH, "rb"))
        print("Loaded UNSW LIME background.")
    except Exception:
        UNSW_LIME_BG = None
        print("UNSW LIME background not found; LIME will fall back to a small zero background (weak).")
    print("Loaded UNSW artifacts.")
except Exception as e:
    print("Warning loading UNSW artifacts:", e)
    UNSW_MODEL = UNSW_SCALER = UNSW_ENCODERS = UNSW_FEAT = None
    UNSW_CATEGORICALS = UNSW_NUMERICS = []
    UNSW_EXPLAINER = None
    UNSW_LIME_BG = None

# ---------------- load CICIDS artifacts ----------------
try:
    CIC_MODEL   = pickle.load(open(CIC_MODEL_PATH, "rb"))
    CIC_SCALER  = pickle.load(open(CIC_SCALER_PATH, "rb"))
    CIC_ENCODERS_RAW = pickle.load(open(CIC_ENCODER_PATH, "rb"))
    CIC_FEAT_RAW = list(pickle.load(open(CIC_FEAT_PATH, "rb")))
    CIC_TARGET_MAP = pickle.load(open(CIC_TARGET_PATH, "rb"))
    CIC_LIME_BG  = pickle.load(open(CIC_LIME_BG_PATH, "rb"))
    # Keep CIC feature names as saved (case-sensitive)
    CIC_FEAT = CIC_FEAT_RAW.copy()
    # Build encoders mapping (expecting mapping dicts saved during training)
    CIC_ENCODERS = {}
    if isinstance(CIC_ENCODERS_RAW, dict):
        for k,v in CIC_ENCODERS_RAW.items():
            CIC_ENCODERS[k] = v
    CIC_CATEGORICALS = [c for c in CIC_FEAT if c in CIC_ENCODERS]
    CIC_NUMERICS = [c for c in CIC_FEAT if c not in CIC_ENCODERS]
    CIC_EXPLAINER = shap.TreeExplainer(CIC_MODEL)
    print("Loaded CICIDS artifacts.")
except Exception as e:
    print("Warning loading CICIDS artifacts:", e)
    CIC_MODEL = CIC_SCALER = CIC_ENCODERS = CIC_FEAT = CIC_TARGET_MAP = CIC_LIME_BG = None
    CIC_CATEGORICALS = CIC_NUMERICS = []
    CIC_EXPLAINER = None

# ---------------- auth ----------------
USERNAME = "admin"
PASSWORD_HASH = generate_password_hash("admin123")

# ---------------- file parser ----------------
def safe_parse_upload(file_bytes):
    df = None
    errors = []
    try:
        sample = file_bytes[:8192].decode(errors="ignore")
        sn = csv.Sniffer()
        try:
            dialect = sn.sniff(sample)
            df = pd.read_csv(io.BytesIO(file_bytes), sep=dialect.delimiter, engine="python")
        except Exception:
            df = pd.read_csv(io.BytesIO(file_bytes), engine="python")
    except Exception as e:
        errors.append(f"csv fail: {e}")
        df = None

    if df is None:
        try:
            df = pd.read_excel(io.BytesIO(file_bytes))
        except Exception as e:
            errors.append(f"excel fail: {e}")
            df = None

    if df is None:
        try:
            df = pd.read_csv(io.BytesIO(file_bytes), sep=r"\s+", engine="python")
        except Exception as e:
            errors.append(f"whitespace fail: {e}")
            df = None

    if df is None:
        return None, "Failed to parse file. " + " | ".join(errors)

    df.columns = df.columns.str.strip()
    return df, None

# ---------------- UNSW helpers ----------------
def _unsw_safe_label_transform(series, le):
    classes = list(le.classes_)
    mapping = {c:i for i,c in enumerate(classes)}
    unk = len(classes)
    return np.array([mapping.get(str(v), unk) for v in series.astype(str)], dtype=int)

def unsw_prepare(df_raw):
    if UNSW_MODEL is None:
        raise RuntimeError("UNSW model not loaded.")
    df = df_raw.copy()
    df.columns = df.columns.str.lower().str.strip()
    for c in UNSW_FEAT:
        if c not in df.columns:
            df[c] = 0
    df = df[UNSW_FEAT].copy()
    for c in UNSW_CATEGORICALS:
        df[c] = _unsw_safe_label_transform(df[c], UNSW_ENCODERS[c])
    for c in UNSW_NUMERICS:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
    X = df.astype(float)
    try:
        fnames = getattr(UNSW_SCALER, "feature_names_in_", None)
        if fnames is not None:
            missing = [f for f in fnames if f not in X.columns]
            for m in missing:
                X[m] = 0.0
            X = X[list(fnames)].astype(float)
    except Exception:
        pass
    Xs = UNSW_SCALER.transform(X)
    return Xs, df

# ---------------- CICIDS helpers ----------------
def _cic_safe_label_transform(series, mapping):
    unk = len(mapping)
    return np.array([mapping.get(str(v), unk) for v in series.astype(str)], dtype=int)

def cic_prepare(df_raw):
    if CIC_MODEL is None:
        raise RuntimeError("CICIDS model not loaded.")
    df = df_raw.copy()
    upload_cols = list(df.columns)
    upload_lower_map = {c.lower(): c for c in upload_cols}
    rename_map = {}
    for model_feat in CIC_FEAT:
        if model_feat in df.columns:
            continue
        key = model_feat.lower()
        if key in upload_lower_map:
            rename_map[ upload_lower_map[key] ] = model_feat
    if rename_map:
        df = df.rename(columns=rename_map)
    for c in CIC_FEAT:
        if c not in df.columns:
            df[c] = 0
    df = df[CIC_FEAT].copy()
    for c in CIC_CATEGORICALS:
        mapping = CIC_ENCODERS.get(c, {})
        df[c] = _cic_safe_label_transform(df[c], mapping)
    for c in CIC_NUMERICS:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
    X = df.astype(float)
    try:
        fnames = getattr(CIC_SCALER, "feature_names_in_", None)
        if fnames is not None:
            missing = [f for f in fnames if f not in X.columns]
            extra = [f for f in X.columns if f not in fnames]
            for m in missing:
                X[m] = 0.0
            if extra:
                X = X.drop(columns=extra)
            X = X[list(fnames)].astype(float)
    except Exception:
        pass
    Xs = CIC_SCALER.transform(X)
    return Xs, df

# ---------------- Visualization helpers ----------------
def save_shap_plot_shallow(explainer, model, Xs, feature_names, idx, save_path, topk=10, title="SHAP"):
    """
    Final upgraded SHAP:
      - signature: (explainer, model, Xs, feature_names, idx, save_path, ...)
      - supports multiclass shap_values (list) or single array
      - handles SHAP length != feature_count by grouping/aggregating
    """
    try:
        shap_values = explainer.shap_values(Xs)

        # multiclass -> pick predicted class for sample idx
        if isinstance(shap_values, list):
            probs = model.predict_proba(Xs)
            pred_class = int(np.argmax(probs[idx]))
            row = shap_values[pred_class][idx]
        else:
            row = shap_values[idx]

        row = np.array(row).flatten()

        # If shap vector length doesn't match feature_names length, try to aggregate
        if len(row) != len(feature_names):
            if len(row) > len(feature_names):
                k = len(row) // len(feature_names)
                if k <= 0:
                    raise ValueError(f"Cannot reshape SHAP values: {len(row)} -> {len(feature_names)}")
                row = row[:(k * len(feature_names))].reshape(len(feature_names), k).sum(axis=1)
            else:
                padded = np.zeros(len(feature_names))
                padded[:len(row)] = row
                row = padded

        feat = np.array(feature_names)
        srt = np.argsort(np.abs(row))[::-1][:topk]
        f = feat[srt]
        v = row[srt]

        colors = ["#27ae60" if float(x) > 0 else "#c0392b" for x in v]

        plt.figure(figsize=(10, 5))
        bars = plt.barh(f[::-1], v[::-1], color=colors[::-1])
        for bar, val in zip(bars, v[::-1]):
            plt.text(bar.get_width(), bar.get_y() + bar.get_height()/2, f"{float(val):.5f}", va="center", fontsize=9)

        plt.title(title, fontsize=13, weight="bold")
        plt.xlabel("SHAP value")
        plt.grid(axis="x", linestyle="--", alpha=0.3)
        plt.tight_layout()
        plt.savefig(save_path, dpi=120)
        plt.close()
        return True, None
    except Exception:
        return False, traceback.format_exc()

def save_lime_plot(Xs, model, feature_names, background, idx, save_path, topk=10, title="LIME - Top Features"):
    try:
        bg = background if (background is not None and getattr(background, "shape", None) is not None and background.shape[0] >= 1) else np.zeros((1, Xs.shape[1]))
        lime_expl = LimeTabularExplainer(training_data=bg,
                                         feature_names=feature_names,
                                         mode="classification")
        exp = lime_expl.explain_instance(Xs[idx], model.predict_proba, num_features=topk)
        feats, vals = zip(*exp.as_list())
        feats = np.array(feats); vals = np.array(vals)
        srt = np.argsort(np.abs(vals))[::-1]
        feats, vals = feats[srt], vals[srt]
        m = min(len(feats), topk)
        feats, vals = feats[:m], vals[:m]
        colors = ["#2ecc71" if float(v) > 0 else "#e74c3c" for v in vals]
        plt.figure(figsize=(10, 5))
        bars = plt.barh(feats[::-1], vals[::-1], color=colors[::-1])
        for bar, val in zip(bars, vals[::-1]):
            plt.text(bar.get_width(), bar.get_y() + bar.get_height()/2, f"{float(val):.5f}", va="center", fontsize=9)
        plt.title(title, fontsize=13, weight="bold")
        plt.xlabel("LIME weight")
        plt.grid(axis="x", linestyle="--", alpha=0.3)
        plt.tight_layout()
        plt.savefig(save_path, dpi=120)
        plt.close()
        return True, None
    except Exception:
        return False, traceback.format_exc()

# ---------------- Routes ----------------
@app.route("/")
def index():
    return render_template("welcome.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        uname = request.form.get("username")
        pwd = request.form.get("password")
        if uname == USERNAME and check_password_hash(PASSWORD_HASH, pwd):
            session["user"] = uname
            return redirect(url_for("predict"))
        return render_template("login.html", error="Invalid username or password")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ---------------- UNSW: single predict + upload/batch ----------------
@app.route("/predict", methods=["GET","POST"])
def predict():
    if "user" not in session:
        return redirect(url_for("login"))
    if request.method == "GET":
        feat_vals = {}
        for c in (UNSW_CATEGORICALS or []):
            le = UNSW_ENCODERS.get(c)
            if le is not None and hasattr(le, "classes_"):
                feat_vals[c] = le.classes_.tolist()
        return render_template("predict.html",
                               feature_list=UNSW_FEAT,
                               categorical_features=UNSW_CATEGORICALS,
                               numeric_features=UNSW_NUMERICS,
                               feature_values=feat_vals)
    data = {c: request.form.get(c) for c in UNSW_FEAT}
    df = pd.DataFrame([data])
    try:
        Xs, df_ordered = unsw_prepare(df)
    except Exception as e:
        flash(f"Prepare error: {e}", "danger")
        return redirect(url_for("predict"))
    pred = UNSW_MODEL.predict(Xs)[0]
    if os.path.exists(UNSW_TARGET_PATH):
        try:
            le_target = pickle.load(open(UNSW_TARGET_PATH, "rb"))
            if hasattr(le_target, "inverse_transform"):
                pred_label = le_target.inverse_transform([pred])[0]
            elif isinstance(le_target, dict):
                inv = {v:k for k,v in le_target.items()}
                pred_label = inv.get(pred, str(pred))
            else:
                pred_label = str(pred)
        except Exception:
            pred_label = str(pred)
    else:
        pred_label = "Normal" if pred == 0 else "Attack"
    uid = str(uuid.uuid4()); plot_dir = os.path.join(BASE_DIR, "static", "plots", uid); os.makedirs(plot_dir, exist_ok=True)
    shap_path = os.path.join(plot_dir, "shap_single.png"); lime_path = os.path.join(plot_dir, "lime_single.png")
    # NOTE: pass UNSW_LIME_BG (if available) — this fixes the identical-LIME-values issue
    ok_s, s_err = save_shap_plot_shallow(UNSW_EXPLAINER, UNSW_MODEL, Xs, UNSW_FEAT, 0, shap_path, title="SHAP - UNSW Top Features")
    ok_l, l_err = save_lime_plot(Xs, UNSW_MODEL, UNSW_FEAT, UNSW_LIME_BG, 0, lime_path, title="LIME - UNSW Top Features")
    return render_template("result.html",
                           prediction=pred_label,
                           shap_img=f"plots/{uid}/shap_single.png",
                           lime_img=f"plots/{uid}/lime_single.png",
                           single_row=df_ordered.iloc[0].to_dict(),
                           severity_color="#2ecc71" if str(pred_label).lower() in ["normal","benign"] else "#dc3545")

@app.route("/upload_preview", methods=["POST"])
def upload_preview():
    if "user" not in session:
        return redirect(url_for("login"))
    file = request.files.get("csvfile")
    if not file:
        flash("No file uploaded", "danger")
        return redirect(url_for("predict"))
    df, err = safe_parse_upload(file.read())
    if df is None:
        flash(err, "danger")
        return redirect(url_for("predict"))
    uid = str(uuid.uuid4()); tmp = f"{uid}.csv"
    df.to_csv(os.path.join(BASE_DIR, "static", "outputs", tmp), index=False)
    preview_html = df.head(20).to_html(classes="table table-striped", index=False)
    return render_template("preview.html", preview_table=Markup(preview_html), tmp_csv=tmp, upload_fname=tmp)

@app.route("/confirm_predict", methods=["POST"])
def confirm_predict():
    if "user" not in session:
        return redirect(url_for("login"))
    tmp = request.form.get("tmp_csv")
    path = os.path.join(BASE_DIR, "static", "outputs", tmp)
    if not os.path.exists(path):
        flash("Temp file not found", "danger")
        return redirect(url_for("predict"))
    df = pd.read_csv(path)
    try:
        Xs, df_proc = unsw_prepare(df)
    except Exception as e:
        flash(f"Prepare error: {e}", "danger")
        return redirect(url_for("predict"))
    preds = UNSW_MODEL.predict(Xs)
    if os.path.exists(UNSW_TARGET_PATH):
        try:
            le_target = pickle.load(open(UNSW_TARGET_PATH, "rb"))
            if hasattr(le_target, "inverse_transform"):
                pred_labels = le_target.inverse_transform(preds)
            elif isinstance(le_target, dict):
                inv = {v:k for k,v in le_target.items()}
                pred_labels = [inv.get(p, str(p)) for p in preds]
            else:
                pred_labels = [str(p) for p in preds]
        except Exception:
            pred_labels = [str(p) for p in preds]
    else:
        pred_labels = ["Normal" if p==0 else "Attack" for p in preds]
    uid = str(uuid.uuid4()); out_name = f"results_{uid}.csv"; out_path = os.path.join(BASE_DIR, "static", "outputs", out_name)
    df_out = df.copy(); df_out["prediction"] = pred_labels; df_out.to_csv(out_path, index=False)
    plot_uid = uid; plot_dir = os.path.join(BASE_DIR, "static", "plots", plot_uid); os.makedirs(plot_dir, exist_ok=True)
    items = []
    max_rows = min(50, len(df_proc))
    for i in range(max_rows):
        shap_fn = f"shap_row_{i}.png"; lime_fn = f"lime_row_{i}.png"
        shap_p = os.path.join(plot_dir, shap_fn); lime_p = os.path.join(plot_dir, lime_fn)
        ok_s, s_err = save_shap_plot_shallow(UNSW_EXPLAINER, UNSW_MODEL, Xs, UNSW_FEAT, i, shap_p, title="SHAP - UNSW Top Features")
        ok_l, l_err = save_lime_plot(Xs, UNSW_MODEL, UNSW_FEAT, UNSW_LIME_BG, i, lime_p, title="LIME - UNSW Top Features")
        items.append({
            "row": i,
            "prediction": pred_labels[i],
            "shap_img": f"plots/{plot_uid}/{shap_fn}",
            "lime_img": f"plots/{plot_uid}/{lime_fn}",
            "shap_ok": ok_s,
            "lime_ok": ok_l,
            "shap_err": s_err,
            "lime_err": l_err
        })
    return render_template("batch_visualization.html", items=items, download_file=out_name)

# ---------------- CICIDS routes ----------------
@app.route("/predict_cicids", methods=["GET","POST"])
def predict_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    if request.method == "GET":
        feat_vals = {}
        for c in (CIC_CATEGORICALS or []):
            mapping = CIC_ENCODERS.get(c, {})
            feat_vals[c] = sorted(list(mapping.keys()))
        return render_template("predict_cicids.html",
                               feature_list=CIC_FEAT,
                               categorical_features=CIC_CATEGORICALS,
                               numeric_features=CIC_NUMERICS,
                               feature_values=feat_vals)
    data = {c: request.form.get(c) for c in CIC_FEAT}
    df = pd.DataFrame([data])
    try:
        Xs, df_proc = cic_prepare(df)
    except Exception as e:
        flash(f"CIC prepare error: {e}", "danger")
        return redirect(url_for("predict_cicids"))
    pred_idx = CIC_MODEL.predict(Xs)[0]
    inv = {v:k for k,v in CIC_TARGET_MAP.items()} if isinstance(CIC_TARGET_MAP, dict) else None
    pred_label = inv.get(pred_idx, str(pred_idx)) if inv is not None else str(pred_idx)
    uid = str(uuid.uuid4()); plot_dir = os.path.join(BASE_DIR, "static", "plots", f"cic_{uid}"); os.makedirs(plot_dir, exist_ok=True)
    shap_p = os.path.join(plot_dir, "shap_single.png"); lime_p = os.path.join(plot_dir, "lime_single.png")
    ok_s, s_err = save_shap_plot_shallow(CIC_EXPLAINER, CIC_MODEL, Xs, CIC_FEAT, 0, shap_p, title="SHAP - CICIDS Top Features")
    ok_l, l_err = save_lime_plot(Xs, CIC_MODEL, CIC_FEAT, CIC_LIME_BG, 0, lime_p, title="LIME - CICIDS Top Features")
    return render_template("result_cicids.html",
                           prediction=pred_label,
                           shap_img=f"plots/cic_{uid}/shap_single.png",
                           lime_img=f"plots/cic_{uid}/lime_single.png",
                           single_row=df_proc.iloc[0].to_dict(),
                           severity_color="#2ecc71" if "benign" in pred_label.lower() else "#dc3545")

@app.route("/upload_preview_cicids", methods=["POST"])
def upload_preview_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    file = request.files.get("csvfile")
    if not file:
        flash("No file uploaded", "danger")
        return redirect(url_for("predict_cicids"))
    df, err = safe_parse_upload(file.read())
    if df is None:
        flash(err, "danger")
        return redirect(url_for("predict_cicids"))
    uid = str(uuid.uuid4()); tmp = f"cic_{uid}.csv"; df.to_csv(os.path.join(BASE_DIR, "static", "outputs", tmp), index=False)
    preview_html = df.head(20).to_html(classes="table table-striped", index=False)
    return render_template("preview.html", preview_table=Markup(preview_html), tmp_csv=tmp, cicids_mode=True, upload_fname=tmp)

@app.route("/confirm_predict_cicids", methods=["POST"])
def confirm_predict_cicids():
    if "user" not in session:
        return redirect(url_for("login"))
    tmp = request.form.get("tmp_csv")
    path = os.path.join(BASE_DIR, "static", "outputs", tmp)
    if not os.path.exists(path):
        flash("Temp file not found", "danger")
        return redirect(url_for("predict_cicids"))
    df = pd.read_csv(path)
    try:
        Xs, df_proc = cic_prepare(df)
    except Exception as e:
        flash(f"CIC prepare error: {e}", "danger")
        return redirect(url_for("predict_cicids"))
    preds_idx = CIC_MODEL.predict(Xs)
    inv = {v:k for k,v in CIC_TARGET_MAP.items()} if isinstance(CIC_TARGET_MAP, dict) else None
    pred_labels = [inv.get(int(p), str(p)) for p in preds_idx] if inv is not None else [str(p) for p in preds_idx]
    uid = str(uuid.uuid4()); out_name = f"cic_results_{uid}.csv"; out_path = os.path.join(BASE_DIR, "static", "outputs", out_name)
    df_out = df.copy(); df_out["prediction"] = pred_labels; df_out.to_csv(out_path, index=False)
    plot_uid = f"cic_{uid}"; plot_dir = os.path.join(BASE_DIR, "static", "plots", plot_uid); os.makedirs(plot_dir, exist_ok=True)
    items = []
    max_rows = min(50, len(df_proc))
    for i in range(max_rows):
        shap_fn = f"shap_{i}.png"; lime_fn = f"lime_{i}.png"
        shap_p = os.path.join(plot_dir, shap_fn); lime_p = os.path.join(plot_dir, lime_fn)
        ok_s, s_err = save_shap_plot_shallow(CIC_EXPLAINER, CIC_MODEL, Xs, CIC_FEAT, i, shap_p, title="SHAP - CICIDS Top Features")
        ok_l, l_err = save_lime_plot(Xs, CIC_MODEL, CIC_FEAT, CIC_LIME_BG, i, lime_p, title="LIME - CICIDS Top Features")
        items.append({
            "row": i,
            "prediction": pred_labels[i],
            "shap_img": f"plots/{plot_uid}/{shap_fn}",
            "lime_img": f"plots/{plot_uid}/{lime_fn}",
            "shap_ok": ok_s,
            "lime_ok": ok_l,
            "shap_err": s_err,
            "lime_err": l_err
        })
    return render_template("batch_visualization_cicids.html", items=items, download_file=out_name)

# ---------------- download route (matches templates) ----------------
@app.route("/download/<path:filename>")
def download_file(filename):
    if "user" not in session:
        return redirect(url_for("login"))
    path = os.path.join(BASE_DIR, "static", "outputs", filename)
    if not os.path.exists(path):
        flash("File not found", "danger")
        return redirect(url_for("predict"))
    return send_file(path, as_attachment=True)

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email")
        flash("Password reset link sent to your email (demo only).", "info")
        return redirect(url_for("login"))
    
    return render_template("forgot_password.html")


# ---------------- run ----------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
